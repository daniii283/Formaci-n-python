from app.db.session import engine
from app.models.smart_device import SmartDevice
from sqlalchemy.orm import declarative_base

Base = declarative_base()
Base.metadata.create_all(bind=engine)

